#!/bin/bash
celery beat -A cyoa.celery
